# A/B Testing: E-commerce Conversion Experiment

A portfolio-ready Python + SQL project evaluating whether a redesigned checkout page (B) improves conversion relative to the original (A).

## Business question
Does the redesigned experience improve purchase conversion? The **generating probabilities** for this synthetic example are 10% for A and 11% for B. Actual sampled rates will differ.

## Dataset
`data/experiment.csv` contains 20,000 **synthetic** independent users, randomized 10,000 per variant, with columns `user_id`, `variant`, `converted` (0/1). This is illustrative data, **not a real company experiment**.

## Statistical method
- H0: p_A = p_B; H1: p_A != p_B (two-sided).
- Two-proportion z-test using pooled standard error under H0.
- 95% normal-approximation (unpooled Wald) confidence interval for absolute lift p_B - p_A.
- Decision threshold alpha=0.05. Statistical significance does not by itself establish business value.

## Quick start
```bash
python -m pip install -r requirements.txt
python -m src.analyze
python -m src.load_sqlite
python -m pytest -q
```

The analysis creates `results/summary.csv`, `results/statistics.json`, and `results/conversion_rates.png`. SQL examples are in `sql/analysis.sql`; run them against `data/experiment.db` using SQLite after running the loader.

## Interpreting results
Check the observed conversion rates, p-value, 95% confidence interval, and absolute/relative lift. A p-value below 0.05 indicates evidence against equal conversion rates under model assumptions; a non-significant result does **not** prove the variants are equivalent. Avoid peeking and repeated significance testing without adjustment.

## Limitations / next steps
This demonstration assumes random assignment, independent observations, reliable tracking, and no missing outcomes. A real study should predefine sample size and minimum detectable effect, monitor assignment balance and guardrail metrics, check data quality, consider practical effect size and costs, and report confidence intervals. Consider CUPED or stratification for more advanced experiments.

## Portfolio presentation
Show `results/conversion_rates.png` and explain the test, effect size, uncertainty, assumptions, and product decision. Include a short discussion of what you'd do differently on real data.
